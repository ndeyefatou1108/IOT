from flask import Flask, render_template, jsonify, request, make_response
import sqlite3
from fpdf import FPDF
import requests

app = Flask(__name__)

# Fonction pour se connecter à la base de données
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Configuration pour l'API météo
API_KEY = '3c33ba4580c24d8177c9a88b32479bfb'
BASE_URL = 'http://api.openweathermap.org/data/2.5/forecast'

# Routes pour les pages web
@app.route('/')
def accueil():
    return render_template('index.html')

@app.route('/consommation')
def consommation():
    conn = get_db_connection()
    factures = conn.execute(
        'SELECT type, SUM(montant) AS total FROM factures GROUP BY type'
    ).fetchall()
    conn.close()
    return render_template('consommation.html', factures=factures)

@app.route('/capteurs')
def capteurs():
    conn = get_db_connection()
    capteurs = conn.execute('SELECT * FROM capteurs').fetchall()
    print(capteurs)
    conn.close()
    return render_template('capteurs.html', capteurs=capteurs)

@app.route('/economies')
def economies():
    conn = get_db_connection()
    factures = conn.execute('SELECT * FROM factures').fetchall()
    conn.close()
    return render_template('economies.html', factures=factures)

@app.route('/configuration')
def configuration():
    conn = get_db_connection()
    capteurs = conn.execute('SELECT * FROM capteurs').fetchall()
    conn.close()
    return render_template('configuration.html', capteurs=capteurs)

# Téléchargement du relevé annuel


# Téléchargement du relevé mensuel
@app.route('/telecharger_mensuel', methods=['GET'])
def telecharger_mensuel_pdf():
    mois = request.args.get('mois', '2024-11')  # Mois par défaut
    conn = get_db_connection()
    factures = conn.execute(
        "SELECT * FROM factures WHERE strftime('%Y-%m', date) = ?", (mois,)
    ).fetchall()
    conn.close()

    pdf = FPDF()
    pdf.add_page()

    # Ajoutez la police
    pdf.add_font('FreeSerif', '', './static/fonts/FreeSerif.ttf', uni=True)
    pdf.add_font('FreeSerif', 'B', './static/fonts/FreeSerifBold.ttf', uni=True)

    # Titre du PDF
    pdf.set_font('FreeSerif', 'B', 16)
    pdf.cell(200, 10, txt=f"Relevé Mensuel - {mois}", ln=True, align='C')
    pdf.ln(10)

    # Informations générales
    pdf.set_font('FreeSerif', '', 12)
    pdf.cell(200, 10, txt="Nom: Votre Nom", ln=True)
    pdf.cell(200, 10, txt="Adresse: Votre Adresse", ln=True)
    pdf.ln(10)

    # En-têtes du tableau
    pdf.set_font('FreeSerif', 'B', 12)
    pdf.cell(50, 10, "Type", 1)
    pdf.cell(50, 10, "Date", 1)
    pdf.cell(50, 10, "Montant (€)", 1)
    pdf.cell(50, 10, "Valeur Consommée", 1)
    pdf.ln()

    # Contenu des factures
    pdf.set_font('FreeSerif', '', 12)
    for facture in factures:
        pdf.cell(50, 10, facture['type'], 1)
        pdf.cell(50, 10, facture['date'], 1)
        pdf.cell(50, 10, f"{facture['montant']:.2f} €", 1)
        pdf.cell(50, 10, f"{facture['valeur_consommée']:.2f}", 1)
        pdf.ln()

    response = make_response(pdf.output(dest='S').encode('latin1'))
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'inline; filename=releve_mensuel.pdf'
    return response





# Téléchargement des mesures
@app.route('/telecharger_mesures', methods=['GET'])
def telecharger_mesures_pdf():
    conn = get_db_connection()
    mesures = conn.execute(
        '''
        SELECT m.id_mesure, m.valeur, m.date_insertion, c.id_capteur, c.id_type
        FROM mesures m
        JOIN capteurs c ON m.id_capteur = c.id_capteur
        ORDER BY m.date_insertion
        '''
    ).fetchall()
    conn.close()

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(200, 10, txt="Relevé des Mesures des Capteurs", ln=True, align='C')
    pdf.ln(10)
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(40, 10, "ID Mesure", 1)
    pdf.cell(40, 10, "Capteur", 1)
    pdf.cell(40, 10, "Valeur", 1)
    pdf.cell(40, 10, "Date", 1)
    pdf.ln()

    pdf.set_font('Arial', '', 12)
    for mesure in mesures:
        pdf.cell(40, 10, str(mesure['id_mesure']), 1)
        pdf.cell(40, 10, str(mesure['id_capteur']), 1)
        pdf.cell(40, 10, f"{mesure['valeur']:.2f}", 1)
        pdf.cell(40, 10, mesure['date_insertion'], 1)
        pdf.ln()

    response = make_response(pdf.output(dest='S').encode('latin1'))
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'inline; filename=releve_mesures.pdf'
    return response

# API pour récupérer les mesures des capteurs existants
@app.route('/api/mesures', methods=['GET'])
def get_mesures_existants():
    conn = get_db_connection()
    mesures = conn.execute(
        '''
        SELECT id_mesure, valeur, id_capteur, date_insertion
        FROM mesures
        WHERE id_capteur != 3
        ORDER BY date_insertion DESC
        '''
    ).fetchall()
    conn.close()
    return jsonify([dict(mesure) for mesure in mesures])

# API pour récupérer les mesures du capteur ESP
@app.route('/api/mesures_esp', methods=['GET'])
def get_mesures():
    conn = get_db_connection()
    mesures = conn.execute(
        '''
        SELECT id_mesure, valeur AS temperature, humidity, date_insertion, id_capteur
        FROM mesures
        ORDER BY date_insertion DESC
        '''
    ).fetchall()
    conn.close()

    results = []
    for mesure in mesures:
        results.append({
            'id_mesure': mesure['id_mesure'],
            'id_capteur': mesure['id_capteur'],
            'temperature': mesure['temperature'],
            'humidity': mesure['humidity'] if mesure['humidity'] is not None else 'N/A',
            'date_insertion': mesure['date_insertion']
        })
    return jsonify(results)


# Route pour recevoir les données de l'ESP8266
@app.route('/api/mesures', methods=['POST'])
def recevoir_mesures():
    try:
        temperature = request.form.get('temperature')
        humidity = request.form.get('humidity')
        id_capteur = request.form.get('id_capteur', 3)  # ID du capteur pour ESP (par défaut 3)

        if not temperature or not humidity:
            return jsonify({'status': 'Erreur', 'message': 'Données manquantes'}), 400

        conn = get_db_connection()
        conn.execute(
            '''
            INSERT INTO mesures (valeur, humidity, date_insertion, id_capteur)
            VALUES (?, ?, CURRENT_TIMESTAMP, ?)
            ''',
            (float(temperature), float(humidity), int(id_capteur))
        )
        conn.commit()
        conn.close()

        return jsonify({'status': 'OK', 'message': 'Données reçues'}), 200
    except Exception as e:
        return jsonify({'status': 'Erreur', 'message': str(e)}), 500
        
        
@app.route('/telecharger_mesures_esp', methods=['GET'])
def telecharger_mesures_esp_pdf():
    conn = get_db_connection()
    mesures = conn.execute(
        '''
        SELECT id_mesure, valeur AS temperature, humidity, date_insertion
        FROM mesures
        WHERE id_capteur = 3
        ORDER BY date_insertion
        '''
    ).fetchall()
    conn.close()

    pdf = FPDF()
    pdf.add_page()
    
    # Utilisation de la police par défaut Helvetica
    pdf.set_font('Helvetica', 'B', 16)
    pdf.cell(200, 10, txt="Relevé des Mesures du Capteur ESP", ln=True, align='C')
    pdf.ln(10)

    # En-têtes du tableau
    pdf.set_font('Helvetica', 'B', 12)
    pdf.cell(50, 10, "ID Mesure", 1)
    pdf.cell(50, 10, "Température (°C)", 1)
    pdf.cell(50, 10, "Humidité (%)", 1)
    pdf.cell(50, 10, "Date", 1)
    pdf.ln()

    # Contenu des mesures
    pdf.set_font('Helvetica', '', 12)
    for mesure in mesures:
        temperature = f"{mesure['temperature']:.2f}" if mesure['temperature'] is not None else 'N/A'
        humidity = f"{mesure['humidity']:.2f}" if mesure['humidity'] is not None else 'N/A'
        pdf.cell(50, 10, str(mesure['id_mesure']), 1)
        pdf.cell(50, 10, temperature, 1)
        pdf.cell(50, 10, humidity, 1)
        pdf.cell(50, 10, mesure['date_insertion'], 1)
        pdf.ln()

    response = make_response(pdf.output(dest='S').encode('latin1'))
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'inline; filename=releve_mesures_esp.pdf'
    return response



@app.route('/meteo_page', methods=['GET'])
def meteo_page():
    ville = request.args.get('ville', 'Paris')  # Par défaut, la ville est Paris
    url = f"{BASE_URL}?q={ville}&units=metric&appid={API_KEY}"
    
    try:
        response = requests.get(url)
        data = response.json()
        
        if response.status_code != 200 or 'list' not in data:
            return render_template('meteo.html', ville=ville, previsions=None, error="Erreur : Impossible de récupérer les données météo.")

        previsions = [
            {
                'date': item['dt_txt'],
                'temperature': item['main']['temp'],
                'description': item['weather'][0]['description']
            }
            for item in data['list'][:5]  # Récupérer les 5 prochaines prévisions
        ]
        return render_template('meteo.html', ville=ville, previsions=previsions, error=None)
    
    except Exception as e:
        return render_template('meteo.html', ville=ville, previsions=None, error=f"Erreur : {str(e)}")



# Lancement du serveur Flask
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

